<?php

class shopUaPluginSettingsAction extends waViewAction
{

}