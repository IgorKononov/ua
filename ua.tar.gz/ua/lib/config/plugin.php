<?php
return array(
    'name' => 'Shop-Script по-украински',
    'description'  => 'Перевод на украинский язык интерфейса Shop-Script и других продуктов Webasyst',
    'img' => 'img/ua.png',
    'version' => '1.0',
    'vendor' => '1077750',
    'custom_settings' => true,
);
